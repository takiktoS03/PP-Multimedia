package com.example.multimedia.data.model

data class AlbumPhoto(
    val album_id: String = "",
    val photo_id: String = ""
)
